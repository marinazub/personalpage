import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowDown } from "lucide-react";

export default function Hero() {
  const scrollToContact = () => {
    document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="min-h-screen flex items-center justify-center relative bg-gradient-to-b from-blue-50/50 to-white/50">
      <div className="absolute inset-0 w-full h-full overflow-hidden z-0">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="object-cover w-full h-full"
        >
          <source src="/background.mp4" type="video/mp4" />
        </video>
        {/* Semi-transparent overlay */}
        <div className="absolute inset-0 bg-white/70"></div>
      </div>

      <div className="container mx-auto px-4 py-20 relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="relative w-full max-w-md mx-auto aspect-square rounded-lg overflow-hidden shadow-xl">
              <img
                src="/profile.webp"
                alt="Marina Zub - Healthcare AI Professional"
                className="object-cover w-full h-full"
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-center md:text-left"
          >
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Marina Zub
            </h1>
            <h2 className="text-2xl md:text-3xl text-primary mb-8">
              CEO & Co-founder at Mentem.Lab
            </h2>
            <p className="text-lg md:text-xl text-gray-600 max-w-2xl mx-auto md:mx-0 mb-12">
              Transforming healthcare through innovative digital solutions. Experienced leader with
              expertise in Digital Health Technology, AI, and Product Development.
            </p>
            <Button
              onClick={scrollToContact}
              size="lg"
              className="group"
            >
              Get in Touch
              <ArrowDown className="ml-2 h-4 w-4 group-hover:translate-y-1 transition-transform" />
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
}