import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";

const journeyItems = [
  {
    year: "Present",
    role: "CEO & Co-founder",
    company: "Mentem.Lab",
    description: "Leading digital health innovation and AI-powered conversational tools development"
  },
  {
    year: "Previous Experience",
    role: "Digital Marketing Technology",
    company: "Various Companies",
    description: "Expert in MarTech solutions, helping Fortune 500 companies deliver seamless omnichannel experiences and personalized customer journeys through tools like Adobe Suite, Salesforce, and Google Marketing Platform"
  }
];

export default function Journey() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-3xl font-bold text-center mb-12"
        >
          Professional Journey
        </motion.h2>
        <div className="max-w-3xl mx-auto">
          {journeyItems.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
            >
              <Card className="mb-6">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-xl font-semibold text-primary">
                        {item.role}
                      </h3>
                      <p className="text-gray-600">{item.company}</p>
                    </div>
                    <span className="text-sm text-gray-500">{item.year}</span>
                  </div>
                  <p className="text-gray-700">{item.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}