import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const blogPosts = [
  {
    id: 1,
    title: "How AI and Simulation Tools Like APLUS are Transforming Healthcare Workflows",
    excerpt: "Today, as I dove deep into readings on AI applications for healthcare, I had a realization — I often struggle to revisit my notes or relocate helpful resources I've found in the past.",
    date: "March 1, 2025",
    slug: "ai-simulation-tools-healthcare-workflows"
  }
];

export default function Blog() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4">Blog</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Insights and thoughts on healthcare technology, AI, and digital innovation
          </p>
        </motion.div>

        <div className="grid gap-8 max-w-4xl mx-auto">
          {blogPosts.map((post) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="text-2xl">
                    {post.title}
                  </CardTitle>
                  <p className="text-sm text-gray-500">{post.date}</p>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">{post.excerpt}</p>
                  <Button asChild>
                    <Link href={`/blog/${post.slug}`}>Read More</Link>
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
