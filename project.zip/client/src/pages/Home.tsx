import { motion } from "framer-motion";
import Hero from "@/components/Hero";
import Journey from "@/components/Journey";
import Skills from "@/components/Skills";
import Company from "@/components/Company";
import Contact from "@/components/Contact";
import Blog from "@/components/Blog";

export default function Home() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen bg-background"
    >
      <Hero />
      <Journey />
      <Skills />
      <Company />
      <Blog />
      <Contact />
    </motion.div>
  );
}