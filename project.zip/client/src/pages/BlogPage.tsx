import BlogPost from "@/components/BlogPost";
import Blog from "@/components/Blog";
import { useLocation } from "wouter";

export default function BlogPage() {
  const [location] = useLocation();
  const match = location.match(/^\/blog\/([\w-]+)$/);

  if (match) {
    return <BlogPost params={{ slug: match[1] }} />;
  }

  return <Blog />;
}
